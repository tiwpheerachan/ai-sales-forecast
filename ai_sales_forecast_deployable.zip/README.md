# AI Sales Forecast App

Streamlit web app for forecasting product sales across campaigns and platforms (Shopee, Lazada).
